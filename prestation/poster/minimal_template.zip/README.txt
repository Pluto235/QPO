Minimal LHAASO / TDLI poster template

Page: 60 x 120 cm, portrait. Editable text is English.
Keep initial_pic/ and fig/ beside minimal_template.tex.
Compile from this folder with:
  pdflatex minimal_template.tex
  pdflatex minimal_template.tex
or:
  tectonic minimal_template.tex

Edit postertitle, author and institute near the top.
Replace the placeholder text and figure boxes inside the four blocks.
Footer: building drawing on the left, TDLI name above Contact
in the center, and your QR image on the right.
The footer logo is clipped in LaTeX to remove its seal and transparent edges,
then displayed at 9 cm width; the complete original PNG is preserved.
The example is compiled and rendered; placeholder content is not final.

The transparent white building drawing is preserved from the reference poster.
The white TDLI logo is the unmodified official PNG from:
https://tdli.sjtu.edu.cn/storage/tdli/web/webcn/file/2024/11/895a01f9e0c4661578b8714f1dcc6f93.png
Official resources: https://tdli.sjtu.edu.cn/en/service-guide/downloads
